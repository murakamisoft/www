package common;

public class Constant {
	public static int SCREEN_WIDTH = 320;
	public static int SCREEN_HEIGHT = 320;
	public static int BULLET_VALUE = 1000;
	public static int WAIT_TIME = 10;
}
