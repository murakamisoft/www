package main;

public class GameManager {

	private int score;
	private int hiScore;
	private final long startTime;
	private boolean endFlag;

	GameManager() {
		score = 0;
		hiScore = 0;
		startTime = System.currentTimeMillis();
		endFlag = false;
	}

	public int checkTime() {
		return (int) (System.currentTimeMillis() - startTime);
	}

	public int getHiScore() {
		return hiScore;
	}

	public int getScore() {
		return score;
	}

	public boolean isEndFlag() {
		return endFlag;
	}

	public void setEndFlag(boolean endFlag) {
		this.endFlag = endFlag;
	}

	public void setHiScore(int hiScore) {
		this.hiScore = hiScore;
	}

	public void setScore(int score) {
		this.score = score;
	}
}
