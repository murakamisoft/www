package main;

public class Chara {
	private float x;
	private float y;
	private float speed;
	private int hp;
	private int size;
	private long damageT1;
	private long damageT2;
	private boolean damage;
	private boolean draw;
	private int life;

	// �_���[�W���󂯂Ă���Ԃ̎���
	private final static long DAMAGE_TIME = 2500;

	Chara() {
		x = 10.0f;
		y = 10.0f;
		speed = 2.0f;
		size = 32;
		damage = false;
		draw = true;
		life = 2;
	}

	public void checkDamageTime() {
		damageT2 = System.currentTimeMillis();

		if (damageT2 - damageT1 > DAMAGE_TIME) {

			setDamage(false);
		}
		if (System.currentTimeMillis() % 2 == 0) {
			draw = !draw;
		}
	}

	public int getHp() {
		return hp;
	}

	public int getLife() {
		return life;
	}

	public int getSize() {
		return size;
	}

	public float getSpeed() {
		return speed;
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public boolean isDamage() {
		return damage;
	}

	public boolean isDraw() {
		return draw;
	}

	public boolean isHit(float bx, float by, int width, int height) {

		// �����蒆�Ȃ甲����
		if (isDamage()) {
			return false;
		}

		if (bx + width > x && bx < x + size && by + height > y && by < y + size) {
			setDamage(true);
			life--;
			return true;
		}
		return false;
	}

	public void setDamage(boolean damage) {
		if (this.damage == false && damage == true) {
			damageT1 = System.currentTimeMillis();
		}
		this.damage = damage;
	}

	public void setDraw(boolean draw) {
		this.draw = draw;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}
}
