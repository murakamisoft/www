package main;

public class Bullet {
	private float x;
	private float y;
	private float addx;
	private float addy;
	private boolean moveFlag;
	private boolean firstFlag;
	int size;

	Bullet() {
		init();
	}

	public void init() {
		addx = 0;
		addy = 0;
		moveFlag = false;
		firstFlag = true;
		size = 16;
	}

	public boolean isFirstFlag() {
		return firstFlag;
	}

	public void setFirstFlag(boolean firstFlag) {
		this.firstFlag = firstFlag;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {

		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {

		this.y = y;

	}

	public boolean isMoveFlag() {
		return moveFlag;
	}

	public void setMoveFlag(boolean moveFlag) {
		this.moveFlag = moveFlag;
	}

	public float getAddx() {
		return addx;
	}

	public float getAddy() {
		return addy;
	}

	public void setAddy(float addy) {
		this.addy = addy;
	}

	// �L������_��
	public void aimX(float aimX) {
		addx = (aimX - x) / 500;
	}

	public void aimY(float aimY) {
		addy = (aimY - y) / 500;
	}
}
