
public class Reversi{

	public static void main(String[] args){
		Title title = new Title();
		GameProc game = new GameProc();
		int putnum;
		int mode;
		
		
		mode = title.drawTitle();
		
		//�R���s���[�^�΃��[�U�[
		if(mode == 1){
			game.Com_User();
		}
		//���[�U�[�΃��[�U�[
		else if(mode == 2){
			game.User_User();
		}
	}
}

class Board{
	
	private int[][] brd = new int[8][8];
	final int WHITE = 1;
	final int BLACK = 2;
	final int NONE = 0;
	final int CANPUT = 3;
	
	Board(){
		this.setBoard(3, 3, BLACK);
		this.setBoard(3, 4, WHITE);
		this.setBoard(4, 3, WHITE);
		this.setBoard(4, 4, BLACK);
	}
	
	//�Ղ̕`��
	public void drawBoard(int m, int e){
		int wcnt;
		int bcnt;
		
		wcnt = 0;
		bcnt = 0;
		
		//�`�b�v���u���邩����
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				this.setCanPut(i, j, 0, 1, m, e, false);
				this.setCanPut(i, j, 0, -1, m, e, false);
				this.setCanPut(i, j, 1, 0, m, e, false);
				this.setCanPut(i, j, -1, 0, m, e, false);
				this.setCanPut(i, j, 1, 1, m, e, false);
				this.setCanPut(i, j, 1, -1, m, e, false);
				this.setCanPut(i, j, -1, 1, m, e, false);
				this.setCanPut(i, j, -1, -1, m, e, false);
			}
		}
		
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(brd[i][j] == WHITE){
					wcnt++;
				}
				else if(brd[i][j] == BLACK){
					bcnt++;
				}
			}
		}
		System.out.println("\n�� : " + wcnt + "  �� : " + bcnt);
		
		System.out.println("����������������������������������");
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(brd[i][j] == NONE){
					System.out.print("��  ");
				}
				else if(brd[i][j] == WHITE){
					System.out.print("����");
				}
				else if(brd[i][j] == BLACK){
					System.out.print("����");
				}
				else if(brd[i][j] == CANPUT){
					System.out.print("��" + (i + 1) + (j + 1));
				}
			}
			System.out.println("��");
			if(i < 7){
				System.out.println("����������������������������������");
			}
		}
		System.out.println("����������������������������������");
	}
	
	//�w�肵���ՂɃ`�b�v���u���邩�ǂ�������
	public int setCanPut(int i, int j, int dirx, int diry, int m, int e, boolean turn){
		int cnt;
		int rnum;
		int x;
		int y;
		int sx;
		int sy;
		
		rnum = 0;
		
		if(brd[i][j] == NONE){
			x = i;
			y = j;
			cnt = 0;
			while(true){
				x += dirx;
				y += diry;
				
				if(x > 7 || x < 0 || y > 7 || y < 0){
					break;
				}
				
				if(brd[x][y] == e){
					cnt++;
				}
				else if(brd[x][y] == NONE || brd[x][y] == CANPUT){
					break;
				}
				else if(brd[x][y] == m && cnt == 0){
					break;
				}
				else if(brd[x][y] == m && cnt > 0){
					//���Ԃ�
					if(turn == true){
						sx = x;
						sy = y;
						x = i;
						y = j;
						while(true){
							
							
							brd[x][y] = m;
							if(m == BLACK){
								System.out.println((x + 1) + "" + (y + 1) + "�����ɂȂ�܂���");
							}
							else if(m == WHITE){
								System.out.println((x + 1) + "" + (y + 1) + "�����ɂȂ�܂���");
							}
							x += dirx;
							y += diry;
							if(x == sx && y == sy){
								break;
							}
						}
					}
					else{
						//�u�u����v���l��\��
						brd[i][j] = CANPUT;
					}
					rnum = cnt;
					break;
				}
			}
		}
		return rnum;
	}
	
	//�Ղ������ς��ŃQ�[�����I�����邩
	public boolean isGameEnd(){
		boolean ret;
		
		ret = true;
		
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(brd[i][j] == CANPUT){
					ret = false;
					break;
				}
			}
		}
		return ret;
	}
	
	public void clrCanPut(){
		for(int i = 0; i < 8; i++){
			for(int j = 0; j < 8; j++){
				if(brd[i][j] == CANPUT){
					brd[i][j] = NONE;
				}
			}
		}
	}
	
	public void setBoard(int i, int j, int n){
		brd[i][j] = n;
	}
	
	public int getBoard(int i, int j){
		return brd[i][j];
	}
}

class Title{
	Title(){
		
	}
	
	public int drawTitle(){
		int inpnum;
		
		while(true){
			System.out.println("**********************************");
			System.out.println("*                                *");
			System.out.println("*        ��Java Reversi��        *");
			System.out.println("*                                *");
			System.out.println("**********************************");
			System.out.println("\n\n\t1 : PC vs Player");
			System.out.println("\t2 : Player vs Player");
			System.out.print("\t0 : End\n\n>>");
			
			inpnum = Input.readInt();
			if(inpnum >= 0 && inpnum <= 2)break;
		}
		return inpnum;
	}
}

class GameProc{
	Board board = new Board();
	public static int mychip;
	public static int enemychip;
	
	GameProc(){
		mychip = board.WHITE;
		enemychip = board.BLACK;
	}
	
	//�R���s���[�^�ΐ�
	public void Com_User(){
		int tx;
		int ty;
		int putnum;
		int tempcol;
		
		while(true){
			board.drawBoard(mychip, enemychip);
			
			//�Q�[���I��
			if(board.isGameEnd() == true){
				break;
			}
			while(true){
				if(mychip == board.WHITE){
					System.out.print("���̔Ԃł�(0�Ńp�X)\n\n>>");
				}
				else if(mychip == board.BLACK){
					System.out.print("���̔Ԃł�(0�Ńp�X)\n\n>>");
				}
				
				putnum = Input.readInt();
				
				if(putnum == 0)break;
				
				tx = (putnum / 10);
				ty = (putnum % 10);
				if(!(tx > 0 && tx <= 8 && ty > 0 && ty <= 8)){
					System.out.println("�\������Ă��鐔�l����͂��ĉ�����\n");
				}
				else if(board.getBoard(tx - 1, ty - 1) == board.CANPUT){
					board.clrCanPut();
					board.setCanPut(tx - 1, ty - 1, 0, 1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 0, -1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 1, 0, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, -1, 0, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 1, 1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 1, -1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, -1, 1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, -1, -1, mychip, enemychip, true);
					break;
				}
			}
			tempcol = mychip;
			mychip = enemychip;
			enemychip = tempcol;
			
			//�u����ԍ����N���A
			board.clrCanPut();
			
		}
	}
	
	//���[�U�[�ΐ�
	public void User_User(){
		int tx;
		int ty;
		int putnum;
		int tempcol;
		
		while(true){
			board.drawBoard(mychip, enemychip);
			
			//�Q�[���I��
			if(board.isGameEnd() == true){
				break;
			}
			while(true){
				if(mychip == board.WHITE){
					System.out.print("���̔Ԃł�(0�Ńp�X)\n\n>>");
				}
				else if(mychip == board.BLACK){
					System.out.print("���̔Ԃł�(0�Ńp�X)\n\n>>");
				}
				
				putnum = Input.readInt();
				
				if(putnum == 0)break;
				
				tx = (putnum / 10);
				ty = (putnum % 10);
				if(!(tx > 0 && tx <= 8 && ty > 0 && ty <= 8)){
					System.out.println("�\������Ă��鐔�l����͂��ĉ�����\n");
				}
				else if(board.getBoard(tx - 1, ty - 1) == board.CANPUT){
					board.clrCanPut();
					board.setCanPut(tx - 1, ty - 1, 0, 1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 0, -1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 1, 0, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, -1, 0, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 1, 1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, 1, -1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, -1, 1, mychip, enemychip, true);
					board.setCanPut(tx - 1, ty - 1, -1, -1, mychip, enemychip, true);
					break;
				}
			}
			tempcol = mychip;
			mychip = enemychip;
			enemychip = tempcol;
			
			//�u����ԍ����N���A
			board.clrCanPut();
			
		}
	}
}